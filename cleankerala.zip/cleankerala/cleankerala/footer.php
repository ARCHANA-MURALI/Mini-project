<footer class="bg-green-400 py-10 text-white">
    <div class="container mx-auto text-center">
      <p>&copy; 2023 QuickFixPro. All rights reserved.</p>
    </div>
  </footer>